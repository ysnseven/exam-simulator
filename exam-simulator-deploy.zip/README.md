# 📝 Exam Simulator

Standalone web app for practicing certification exams from Markdown question files.

## 🚀 Live Demo

Open `index.html` directly or deploy to any static host.

## ✨ Features

- 📄 Upload `.md` question files (auto-parses multiple formats)
- 🎯 Dynamic topic detection from your file
- ⏱ Optional timed mode (15s–300s per question)
- 🔀 Shuffle questions & topic filtering
- 🤖 Optional AI Verify with Anthropic API (Claude Sonnet 4)
- 🌙 Dark / Light theme toggle
- ⌨️ Keyboard shortcuts (A–E, Enter, ←/→)
- 📱 Mobile & tablet responsive

## 📋 Supported Question Formats

| Format | Example |
|--------|---------|
| SecExams PDF | `Question #3` → `A) opt` `B) opt (Correct Answer)` |
| Heading style | `## Question #NNN` → options → `### Correct Answer: **B**` |
| Numbered | `### 1. Question?` → `A) opt` → `**Answer:** B` |
| Key-value | `Q: text` / `A: opt` / `ANSWER: B` / `---` |
| Multi-select | `Correct Answer: BD` or `B, D` |
| ✅ marker | `B) option ✅ (Correct Answer)` |

## 🛠 Tech Stack

- React 18 (via CDN — no build step)
- Babel Standalone (runtime JSX compile)
- Single HTML file (zero dependencies after first load)

## 📜 License

Personal use.
